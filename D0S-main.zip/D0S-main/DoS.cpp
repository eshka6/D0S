#include <cmath>
#include <iostream>
#include <string>
#include <algorithm>
#include <thread>
#include <chrono>
#include <windows.h>
#include <fstream>

using namespace std;

int main() {
    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);
    
    // НАЧАЛО ОБЫЧНОГО И РОВНОГО АРТА D0S-S0S
    cout << "==========================================================" << endl;
    cout << "  _____     ____     _____     _____     ____     _____" << endl;
    cout << " |  __ \\  / __ \\  / ____|   / ____|   / __ \\  / ____|" << endl;
    cout << " | |  | | | |  | | | (___    | (___    | |  | | | (___  " << endl;
    cout << " | |  | | | |  | |  \\___ \\  \\___ \\ | |  | |  \\___ \\ " << endl;
    cout << " | |__| | | |__| |   ____) |   ____) | | |__| |  ____) |" << endl;
    cout << " |_____/   \\____/  |_____/   |_____/   \\____/  |_____/ " << endl;
    cout << "                                                          " << endl;
    cout << "================== Created by eshka6 =====================" << endl;
    cout << endl;

    cout << "Starting Programm..." << endl;
    this_thread::sleep_for(chrono::seconds(2));
    
    cout << "Welcome You on D0S-S0S" << endl;
    cout << "[START D0S 1] [QUIT 0]" << endl;
    
    int dos = 1;
    int quit = 0;
    int user_input;
    cin >> user_input;
    
    if (user_input == 1) {
        ofstream file("D0S-Script_OutPut.txt", ios::app);
        cout << "Starting D0S..." << endl;
        
        while(true) {
            file << "ProccessingD0S_27318973891783873187138731879317981398713" << endl;
            cout << "D0Sing..." << endl;
        }
    }
    else if (user_input == 0) {
        cout << "Quiting..." << endl;
        this_thread::sleep_for(chrono::seconds(2));
        exit(0);
    }
    else {
        cout << "Retry" << endl;
    }
    
    return 0;
}